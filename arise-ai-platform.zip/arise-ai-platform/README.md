# ARISE — AI Teacher Assistant

A full-stack prototype for **Modern Minds, Rooted Souls**. It includes:
- AI-generated explanations, examples, classroom activities, quizzes with answer keys, lesson plans, worksheets and values reflections.
- An AI doubt-solving chat adapted to school class level.
- Local-only activity counters (no student accounts or identity fields).
- A secure server-side OpenAI connection; the API key is never sent to the browser.

## Requirements
- Node.js 20 or newer
- An OpenAI API key with API billing/usage enabled

## Run locally
1. Extract this project folder.
2. In a terminal inside the folder, run `npm install`.
3. Copy `.env.example` to `.env`.
4. Put your API key in `.env` as `OPENAI_API_KEY=...` and keep `.env` private.
5. Run `npm start`.
6. Open `http://localhost:3000`.

The default model is `gpt-5.5`. You can change `OPENAI_MODEL` in the server environment if your API account has access to another supported model.

## Important deployment note
GitHub Pages can host static HTML but cannot safely store a secret API key or run this Node server. Deploy this complete project to a Node-compatible host (for example, a managed app host) and add `OPENAI_API_KEY` in that host's private environment-variable settings. Do not put the key in `public/index.html`, GitHub commits, screenshots or chat messages.

## Privacy and safety
- Do not collect student names, phone numbers, addresses, school IDs or other personal data.
- Local activity counters are stored in the current browser only.
- AI output can be inaccurate; a teacher must review it before classroom use.
- This is a prototype, not a student information system or a validated assessment product.
