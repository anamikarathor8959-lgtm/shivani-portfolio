import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import OpenAI from 'openai';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = Number(process.env.PORT || 3000);
const model = process.env.OPENAI_MODEL || 'gpt-5.5';

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '30kb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: 'draft-8', legacyHeaders: false }));
app.use(express.static(path.join(__dirname, 'public')));

const client = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

const sharedInstructions = `You are ARISE, a teacher-support and student-learning assistant for school-level learners. ARISE means “Modern Minds, Rooted Souls.”
Use age-appropriate, inclusive, encouraging language. Explain concepts clearly and adapt to the stated class level. Prefer examples from everyday life and the learner's local context without assuming their location or background. Support curiosity, critical thinking, empathy, honesty, respect, responsibility and reflection. Spirituality/value content must be inclusive and non-coercive; never promote one religion or belief as compulsory.
Do not ask for or encourage sharing a student's full name, address, phone number, school ID, passwords, precise location, photos, or other personal information. If such details appear, do not repeat them; remind the user not to share personal information.
For health, legal, safety or other high-stakes topics, provide general educational information and encourage asking a trusted adult or qualified professional. Never present uncertain facts as certain. State when a teacher should verify curriculum-specific details. Do not generate humiliating, discriminatory, sexual, violent, or otherwise age-inappropriate content.
Be useful and structured. Do not claim to know the learner's grades or progress unless those are included in the current request.`;

function cleanString(value, max = 4000) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, aiConfigured: Boolean(client), model: client ? model : null });
});

app.post('/api/generate', async (req, res) => {
  if (!client) return res.status(503).json({ error: 'The AI service is not configured yet. Add OPENAI_API_KEY to the server environment.' });
  const subject = cleanString(req.body.subject, 100) || 'General Studies';
  const level = cleanString(req.body.level, 50) || 'Class 8';
  const topic = cleanString(req.body.topic, 180);
  const objective = cleanString(req.body.objective, 600) || 'Understand the key ideas and connect them to everyday life.';
  const kind = cleanString(req.body.kind, 30);
  const language = cleanString(req.body.language, 40) || 'Simple English';
  const validKinds = new Set(['explain', 'examples', 'activity', 'assessment', 'lesson', 'worksheet', 'values']);
  if (!topic) return res.status(400).json({ error: 'Please enter a topic.' });
  if (!validKinds.has(kind)) return res.status(400).json({ error: 'Choose a valid resource type.' });

  const labels = {
    explain: 'A clear, simple topic explanation with key terms, a worked example and a short recap',
    examples: 'At least four accurate real-life examples, each explained simply',
    activity: 'A safe, inclusive, low-cost classroom activity with objective, time, materials, steps and reflection',
    assessment: 'A short assessment with a mix of multiple-choice and short-answer questions, plus an answer key and explanations',
    lesson: 'A complete lesson plan with objectives, prior knowledge, materials, timed teaching sequence, checks for understanding and homework/extension',
    worksheet: 'A printable worksheet with graduated difficulty and a separate answer key',
    values: 'A values-based learning reflection connecting the topic to empathy, responsibility, honesty or critical thinking without religious coercion'
  };

  try {
    const response = await client.responses.create({
      model,
      instructions: sharedInstructions,
      input: `Create: ${labels[kind]}\nSubject: ${subject}\nClass/level: ${level}\nTopic: ${topic}\nLearning objective: ${objective}\nLanguage: ${language}\n\nUse headings and numbered steps where useful. Be accurate and transparent about uncertainty. End with a short “Teacher review” note identifying any curriculum-specific facts that should be checked.`,
      max_output_tokens: 1400
    });
    res.json({ text: response.output_text || 'No text was returned. Please try again.' });
  } catch (error) {
    console.error('Generation error:', error?.message || error);
    res.status(500).json({ error: 'The AI request could not be completed. Please try again in a moment.' });
  }
});

app.post('/api/chat', async (req, res) => {
  if (!client) return res.status(503).json({ error: 'The AI service is not configured yet. Add OPENAI_API_KEY to the server environment.' });
  const question = cleanString(req.body.question, 1200);
  const level = cleanString(req.body.level, 50) || 'Class 8';
  const subject = cleanString(req.body.subject, 100) || 'General learning';
  if (!question) return res.status(400).json({ error: 'Please type a question.' });
  try {
    const response = await client.responses.create({
      model,
      instructions: `${sharedInstructions}\nYou are in ARISE doubt-solving mode. Answer the question step by step at ${level} level in ${subject}. Start with a direct simple answer, explain the reasoning, then give one small check-for-understanding question. If the question is ambiguous, ask one concise clarification.`,
      input: question,
      max_output_tokens: 900
    });
    res.json({ text: response.output_text || 'I could not prepare an answer. Please rephrase your question.' });
  } catch (error) {
    console.error('Chat error:', error?.message || error);
    res.status(500).json({ error: 'The AI assistant is temporarily unavailable. Please try again.' });
  }
});

app.use((_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(port, () => console.log(`ARISE is running on http://localhost:${port}`));
